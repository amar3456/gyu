module.exports = {
    Workout: require("./Workout"),
    Exercise: require("./Exercise")
  };